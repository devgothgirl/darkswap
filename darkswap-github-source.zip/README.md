# DarkSwap

DarkSwap is a Solana-first exchange with two distinct flows:

- **Private routes:** HoudiniSwap quotes and deposit-based orders without connecting a wallet.
- **Public routes:** OKX DEX same-chain Solana swaps that require a connected wallet to review, sign, and send a transaction. These swaps are visible on-chain.

The Explore page uses Tokens.xyz for asset and market data and Helius for Solana on-chain metadata. In-app OKX bridging is not implemented; the app links to OKX's separate bridge product instead.

## Project layout

- `artifacts/solana-privacy-swap` — React/Vite web app
- `artifacts/api-server` — Express API; provider credentials remain server-side
- `lib/api-spec` — OpenAPI contract and code generation
- `lib/api-client-react`, `lib/api-zod` — generated client and validation schemas
- `lib/db`, `scripts` — supporting workspace packages

## Setup

Use Node.js 24 and pnpm. From the repository root:

```bash
pnpm install --frozen-lockfile
pnpm --filter @workspace/api-spec run codegen
pnpm run typecheck
```

Add these values to your hosting environment's **secrets**, not to GitHub:

| Secret | Purpose |
| --- | --- |
| `HOUDINI_API_KEY`, `HOUDINI_API_SECRET` | Private route quotes and orders |
| `HELIUS_API_KEY` | Solana on-chain metadata |
| `TOKENS_XYZ_API_KEY` | Token discovery and market data |
| `OKX_API_KEY`, `OKX_API_SECRET`, `OKX_API_PASSPHRASE` | Public OKX DEX quotes and transaction building |

The included Replit artifact manifests configure the web and API workflows and route `/api` to the API server. If running outside Replit, provide `PORT` to each service, `BASE_PATH=/` to the web service, and a reverse proxy that routes `/api` to the API server:

```bash
PORT=8080 pnpm --filter @workspace/api-server run dev
PORT=18223 BASE_PATH=/ pnpm --filter @workspace/solana-privacy-swap run dev
```

Never commit `.env` files, API credentials, wallet seed phrases, or private keys. A connected user's wallet signs OKX transactions locally; the app does not need or collect wallet keys.
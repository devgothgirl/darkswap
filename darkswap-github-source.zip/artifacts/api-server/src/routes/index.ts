import { Router, type IRouter } from "express";
import healthRouter from "./health";
import swapRouter from "./swap";
import discoveryRouter from "./discovery";
import okxRouter from "./okx";

const router: IRouter = Router();

router.use(healthRouter);
router.use(swapRouter);
router.use(discoveryRouter);
router.use(okxRouter);

export default router;

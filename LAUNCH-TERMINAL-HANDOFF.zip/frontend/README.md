# DarkSwap Launch — prepared standalone frontend

This is a production root-mounted (`BASE_PATH=/`) frontend with bundled SSR.
Preparation is complete, but this directory is NOT a live deployment or proof
that a custom domain, DNS, TLS, API routing, sessions or provider access works.

Prepared target: https://darkswap.world. The owner chose this instead of
launch.darkswap.app. Preparation does not authorize replacing the current
darkswap.world site, publishing, DNS changes or production setting changes.
darkswap.app must remain unchanged.

Serve public/ assets through the gateway; do not serve index.html as a static
page fallback. Start the loopback SSR renderer with node serve.mjs, setting
LAUNCH_SSR_PORT to the selected internal port and LAUNCH_PUBLIC_API_ORIGIN to a
verified HTTPS API origin serving public /api discovery endpoints. SSR uses only
anonymous public requests; it never forwards browser cookies or request headers.
The Nginx page routes use that same LAUNCH_SSR_PORT. Missing assets return 404.
Public routes include /docs, /terms, /privacy and /risk as well as discovery.

The frontend still requests same-origin /api endpoints. No API server is included.
Route ONLY the allowlisted Launch API paths to the separately operated DarkSwap
backend's /launch/api ingress BEFORE SPA/SSR page handling. Deny all other /api paths.
The backend must receive Host: darkswap.world, effective protocol https, and
the unchanged browser Origin/cookies/CSRF headers; ordinary proxying to a
different hostname is not sufficient. The proposed production setting is
LAUNCH_ALLOWED_ORIGINS=https://darkswap.world; it has NOT been applied.
Review backend origin, cookie/session and CSRF requirements before use.
Do not put provider secrets in frontend environment variables or static files.

nginx.conf.template is copied unchanged from the reviewed source template. It is
an example to review and configure, NOT an installed or validated server config.
Set its PUBLIC_DIR to the absolute path of this package's public/ directory.
Keep server/, serve.mjs, seo-config.json, package.json, this README, the manifest
and the template outside the static document root.
No hosting provider, publishing, DNS, TLS or live API action was performed.

See docs/launch-standalone-deployment.md in the source repository for the complete
deployment procedure and limitations. Consult standalone-manifest.json for the
preparation marker. Deployment and live verification are separate operator steps.
